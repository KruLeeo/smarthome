package com.example.testik2

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
