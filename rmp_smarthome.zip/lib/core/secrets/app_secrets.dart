class AppSecrets{
  static const supabaseUrl = 'https://wqwdzmfoludbrbvewred.supabase.co';
  static const supabaseAnnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Indxd2R6bWZvbHVkYnJidmV3cmVkIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDU3NjQzNzAsImV4cCI6MjA2MTM0MDM3MH0.ZZ1ZeEugTzdWl-tyCXzCRlZ1gMcvAEwpLULICaAUt1Q';
}