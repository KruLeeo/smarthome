class ServerException{
  final String message;
  ServerException(this.message);
}